jQuery(document).ready(function ($) {
  $(".colorpicker").wpColorPicker();
}); // End Document Ready JQuery
