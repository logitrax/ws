<div class="six columns">
	<a href="<?php echo get_permalink(get_option('job_manager_submit_job_form_page_id')); ?>" class="button"><?php esc_html_e('Post a Job, It\'s Free!','workscout'); ?></a>
</div>